import {
  type Part,
  type InsertPart,
  type Build,
  type InsertBuild,
  type PartCategory,
  type Retailer,
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Parts
  getAllParts(): Promise<Part[]>;
  getPartsByCategory(category: PartCategory): Promise<Part[]>;
  getPartById(id: string): Promise<Part | undefined>;
  getPartsByIds(ids: string[]): Promise<Part[]>;
  createPart(part: InsertPart): Promise<Part>;

  // Builds
  getAllBuilds(): Promise<Build[]>;
  getBuildById(id: string): Promise<Build | undefined>;
  createBuild(build: InsertBuild): Promise<Build>;
  updateBuild(id: string, build: Partial<InsertBuild>): Promise<Build | undefined>;
  deleteBuild(id: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private parts: Map<string, Part>;
  private builds: Map<string, Build>;

  constructor() {
    this.parts = new Map();
    this.builds = new Map();
    this.seedParts();
  }

  private seedParts() {
    const sampleParts: Omit<Part, "id">[] = [
      // CPUs
      {
        name: "AMD Ryzen 9 7950X",
        category: "CPU",
        price: 32500,
        imageUrl: null,
        specs: {
          Cores: "16",
          Threads: "32",
          "Base Clock": "4.5 GHz",
          "Boost Clock": "5.7 GHz",
        },
        retailer: "PC Express",
        available: ["PC Express", "EasyPC"],
        socket: "AM5",
        chipset: null,
        formFactor: null,
        ramType: "DDR5",
        wattage: null,
        tdp: 170,
      },
      {
        name: "Intel Core i9-14900K",
        category: "CPU",
        price: 38000,
        imageUrl: null,
        specs: {
          Cores: "24",
          Threads: "32",
          "Base Clock": "3.2 GHz",
          "Boost Clock": "6.0 GHz",
        },
        retailer: "EasyPC",
        available: ["EasyPC", "Lazada"],
        socket: "LGA1700",
        chipset: null,
        formFactor: null,
        ramType: "DDR5",
        wattage: null,
        tdp: 253,
      },
      {
        name: "AMD Ryzen 7 7800X3D",
        category: "CPU",
        price: 25000,
        imageUrl: null,
        specs: {
          Cores: "8",
          Threads: "16",
          "Base Clock": "4.2 GHz",
          "Boost Clock": "5.0 GHz",
        },
        retailer: "Lazada",
        available: ["Lazada", "Shopee"],
        socket: "AM5",
        chipset: null,
        formFactor: null,
        ramType: "DDR5",
        wattage: null,
        tdp: 120,
      },
      {
        name: "Intel Core i5-14600K",
        category: "CPU",
        price: 18500,
        imageUrl: null,
        specs: {
          Cores: "14",
          Threads: "20",
          "Base Clock": "3.5 GHz",
          "Boost Clock": "5.3 GHz",
        },
        retailer: "Shopee",
        available: ["Shopee", "PC Express"],
        socket: "LGA1700",
        chipset: null,
        formFactor: null,
        ramType: "DDR5",
        wattage: null,
        tdp: 181,
      },
      // GPUs
      {
        name: "NVIDIA GeForce RTX 4090 Ti",
        category: "GPU",
        price: 58000,
        imageUrl: null,
        specs: {
          "VRAM": "24GB GDDR6X",
          "Boost Clock": "2.6 GHz",
          "CUDA Cores": "16384",
        },
        retailer: "PC Express",
        available: ["PC Express", "EasyPC"],
        socket: null,
        chipset: null,
        formFactor: null,
        ramType: null,
        wattage: null,
        tdp: 450,
      },
      {
        name: "AMD Radeon RX 7900 XTX",
        category: "GPU",
        price: 48000,
        imageUrl: null,
        specs: {
          "VRAM": "24GB GDDR6",
          "Boost Clock": "2.5 GHz",
          "Stream Processors": "6144",
        },
        retailer: "EasyPC",
        available: ["EasyPC", "Lazada"],
        socket: null,
        chipset: null,
        formFactor: null,
        ramType: null,
        wattage: null,
        tdp: 355,
      },
      {
        name: "NVIDIA GeForce RTX 4070 Super",
        category: "GPU",
        price: 36000,
        imageUrl: null,
        specs: {
          "VRAM": "12GB GDDR6X",
          "Boost Clock": "2.48 GHz",
          "CUDA Cores": "7168",
        },
        retailer: "Lazada",
        available: ["Lazada", "Shopee", "PC Express"],
        socket: null,
        chipset: null,
        formFactor: null,
        ramType: null,
        wattage: null,
        tdp: 220,
      },
      // Motherboards
      {
        name: "ASUS ROG Strix X670E-E Gaming WiFi",
        category: "Motherboard",
        price: 28000,
        imageUrl: null,
        specs: {
          Socket: "AM5",
          Chipset: "X670E",
          "Form Factor": "ATX",
          "Memory Type": "DDR5",
        },
        retailer: "PC Express",
        available: ["PC Express", "EasyPC"],
        socket: "AM5",
        chipset: "X670E",
        formFactor: "ATX",
        ramType: "DDR5",
        wattage: null,
        tdp: null,
      },
      {
        name: "MSI MAG Z790 Tomahawk WiFi",
        category: "Motherboard",
        price: 24000,
        imageUrl: null,
        specs: {
          Socket: "LGA1700",
          Chipset: "Z790",
          "Form Factor": "ATX",
          "Memory Type": "DDR5",
        },
        retailer: "EasyPC",
        available: ["EasyPC", "Shopee"],
        socket: "LGA1700",
        chipset: "Z790",
        formFactor: "ATX",
        ramType: "DDR5",
        wattage: null,
        tdp: null,
      },
      {
        name: "Gigabyte B650 AORUS Elite AX",
        category: "Motherboard",
        price: 15500,
        imageUrl: null,
        specs: {
          Socket: "AM5",
          Chipset: "B650",
          "Form Factor": "ATX",
          "Memory Type": "DDR5",
        },
        retailer: "Shopee",
        available: ["Shopee", "Lazada"],
        socket: "AM5",
        chipset: "B650",
        formFactor: "ATX",
        ramType: "DDR5",
        wattage: null,
        tdp: null,
      },
      // RAM
      {
        name: "Corsair Vengeance DDR5 32GB (2×16GB) 6000MHz",
        category: "RAM",
        price: 8500,
        imageUrl: null,
        specs: {
          Capacity: "32GB (2×16GB)",
          Speed: "6000 MHz",
          Type: "DDR5",
          CAS: "CL36",
        },
        retailer: "Shopee",
        available: ["Shopee", "PC Express"],
        socket: null,
        chipset: null,
        formFactor: null,
        ramType: "DDR5",
        wattage: null,
        tdp: null,
      },
      {
        name: "G.Skill Trident Z5 RGB 32GB (2×16GB) 6400MHz",
        category: "RAM",
        price: 9800,
        imageUrl: null,
        specs: {
          Capacity: "32GB (2×16GB)",
          Speed: "6400 MHz",
          Type: "DDR5",
          CAS: "CL32",
        },
        retailer: "PC Express",
        available: ["PC Express", "EasyPC"],
        socket: null,
        chipset: null,
        formFactor: null,
        ramType: "DDR5",
        wattage: null,
        tdp: null,
      },
      {
        name: "Kingston Fury Beast DDR5 32GB (2×16GB) 5200MHz",
        category: "RAM",
        price: 7200,
        imageUrl: null,
        specs: {
          Capacity: "32GB (2×16GB)",
          Speed: "5200 MHz",
          Type: "DDR5",
          CAS: "CL40",
        },
        retailer: "Lazada",
        available: ["Lazada", "Shopee"],
        socket: null,
        chipset: null,
        formFactor: null,
        ramType: "DDR5",
        wattage: null,
        tdp: null,
      },
      {
        name: "Corsair Vengeance DDR5 64GB (2×32GB) 5800MHz",
        category: "RAM",
        price: 15500,
        imageUrl: null,
        specs: {
          Capacity: "64GB (2×32GB)",
          Speed: "5800 MHz",
          Type: "DDR5",
          CAS: "CL40",
        },
        retailer: "EasyPC",
        available: ["EasyPC", "PC Express"],
        socket: null,
        chipset: null,
        formFactor: null,
        ramType: "DDR5",
        wattage: null,
        tdp: null,
      },
      // Storage
      {
        name: "Samsung 990 PRO 2TB NVMe SSD",
        category: "Storage",
        price: 9500,
        imageUrl: null,
        specs: {
          Capacity: "2TB",
          Interface: "NVMe PCIe 4.0",
          "Read Speed": "7,450 MB/s",
          "Write Speed": "6,900 MB/s",
        },
        retailer: "PC Express",
        available: ["PC Express", "Lazada"],
        socket: null,
        chipset: null,
        formFactor: "M.2",
        ramType: null,
        wattage: null,
        tdp: null,
      },
      {
        name: "WD Black SN850X 1TB NVMe SSD",
        category: "Storage",
        price: 5800,
        imageUrl: null,
        specs: {
          Capacity: "1TB",
          Interface: "NVMe PCIe 4.0",
          "Read Speed": "7,300 MB/s",
          "Write Speed": "6,300 MB/s",
        },
        retailer: "Shopee",
        available: ["Shopee", "EasyPC"],
        socket: null,
        chipset: null,
        formFactor: "M.2",
        ramType: null,
        wattage: null,
        tdp: null,
      },
      // PSU
      {
        name: "Corsair RM850x 850W 80+ Gold",
        category: "PSU",
        price: 7500,
        imageUrl: null,
        specs: {
          Wattage: "850W",
          Certification: "80+ Gold",
          Modular: "Fully Modular",
        },
        retailer: "PC Express",
        available: ["PC Express", "EasyPC"],
        socket: null,
        chipset: null,
        formFactor: "ATX",
        ramType: null,
        wattage: 850,
        tdp: null,
      },
      {
        name: "Seasonic Focus GX-750 750W 80+ Gold",
        category: "PSU",
        price: 6200,
        imageUrl: null,
        specs: {
          Wattage: "750W",
          Certification: "80+ Gold",
          Modular: "Fully Modular",
        },
        retailer: "Lazada",
        available: ["Lazada", "Shopee"],
        socket: null,
        chipset: null,
        formFactor: "ATX",
        ramType: null,
        wattage: 750,
        tdp: null,
      },
      // Cases
      {
        name: "Lian Li O11 Dynamic EVO",
        category: "Case",
        price: 9800,
        imageUrl: null,
        specs: {
          Type: "Mid Tower",
          "Form Factor": "ATX",
          Color: "Black",
        },
        retailer: "PC Express",
        available: ["PC Express", "EasyPC"],
        socket: null,
        chipset: null,
        formFactor: "ATX",
        ramType: null,
        wattage: null,
        tdp: null,
      },
      {
        name: "NZXT H510 Flow",
        category: "Case",
        price: 5500,
        imageUrl: null,
        specs: {
          Type: "Mid Tower",
          "Form Factor": "ATX",
          Color: "White",
        },
        retailer: "Shopee",
        available: ["Shopee", "Lazada"],
        socket: null,
        chipset: null,
        formFactor: "ATX",
        ramType: null,
        wattage: null,
        tdp: null,
      },
      // Cooling
      {
        name: "NZXT Kraken X63 280mm AIO",
        category: "Cooling",
        price: 8900,
        imageUrl: null,
        specs: {
          Type: "AIO Liquid Cooler",
          "Radiator Size": "280mm",
          "Fan Speed": "500-1800 RPM",
        },
        retailer: "PC Express",
        available: ["PC Express", "EasyPC"],
        socket: null,
        chipset: null,
        formFactor: null,
        ramType: null,
        wattage: null,
        tdp: null,
      },
      {
        name: "Noctua NH-D15 chromax.black",
        category: "Cooling",
        price: 6500,
        imageUrl: null,
        specs: {
          Type: "Air Cooler",
          Height: "165mm",
          "TDP Rating": "250W",
        },
        retailer: "EasyPC",
        available: ["EasyPC", "Lazada"],
        socket: null,
        chipset: null,
        formFactor: null,
        ramType: null,
        wattage: null,
        tdp: null,
      },
    ];

    sampleParts.forEach((partData) => {
      const id = randomUUID();
      const part: Part = { ...partData, id };
      this.parts.set(id, part);
    });
  }

  // Parts methods
  async getAllParts(): Promise<Part[]> {
    return Array.from(this.parts.values());
  }

  async getPartsByCategory(category: PartCategory): Promise<Part[]> {
    return Array.from(this.parts.values()).filter((part) => part.category === category);
  }

  async getPartById(id: string): Promise<Part | undefined> {
    return this.parts.get(id);
  }

  async getPartsByIds(ids: string[]): Promise<Part[]> {
    return ids.map((id) => this.parts.get(id)).filter((part): part is Part => part !== undefined);
  }

  async createPart(insertPart: InsertPart): Promise<Part> {
    const id = randomUUID();
    const part: Part = {
      ...insertPart,
      id,
      imageUrl: insertPart.imageUrl ?? null,
      socket: insertPart.socket ?? null,
      chipset: insertPart.chipset ?? null,
      formFactor: insertPart.formFactor ?? null,
      ramType: insertPart.ramType ?? null,
      wattage: insertPart.wattage ?? null,
      tdp: insertPart.tdp ?? null,
    };
    this.parts.set(id, part);
    return part;
  }

  // Builds methods
  async getAllBuilds(): Promise<Build[]> {
    return Array.from(this.builds.values());
  }

  async getBuildById(id: string): Promise<Build | undefined> {
    return this.builds.get(id);
  }

  async createBuild(insertBuild: InsertBuild): Promise<Build> {
    const id = randomUUID();
    const build: Build = {
      ...insertBuild,
      id,
      compatible: insertBuild.compatible ?? null,
      createdAt: new Date().toISOString(),
    };
    this.builds.set(id, build);
    return build;
  }

  async updateBuild(id: string, updates: Partial<InsertBuild>): Promise<Build | undefined> {
    const build = this.builds.get(id);
    if (!build) return undefined;

    const updatedBuild: Build = { ...build, ...updates };
    this.builds.set(id, updatedBuild);
    return updatedBuild;
  }

  async deleteBuild(id: string): Promise<boolean> {
    return this.builds.delete(id);
  }
}

export const storage = new MemStorage();
