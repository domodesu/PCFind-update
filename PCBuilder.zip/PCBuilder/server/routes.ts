import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertBuildSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all parts or filter by category
  app.get("/api/parts", async (req, res) => {
    try {
      const category = req.query.category as string | undefined;

      if (category) {
        const parts = await storage.getPartsByCategory(category as any);
        return res.json(parts);
      }

      const parts = await storage.getAllParts();
      res.json(parts);
    } catch (error) {
      console.error("Error fetching parts:", error);
      res.status(500).json({ message: "Failed to fetch parts" });
    }
  });

  // Get part by ID
  app.get("/api/parts/:id", async (req, res) => {
    try {
      const part = await storage.getPartById(req.params.id);

      if (!part) {
        return res.status(404).json({ message: "Part not found" });
      }

      res.json(part);
    } catch (error) {
      console.error("Error fetching part:", error);
      res.status(500).json({ message: "Failed to fetch part" });
    }
  });

  // Get multiple parts by IDs (for build summary)
  app.post("/api/parts/selected", async (req, res) => {
    try {
      const { ids } = req.body;

      if (!Array.isArray(ids)) {
        return res.status(400).json({ message: "IDs must be an array" });
      }

      const parts = await storage.getPartsByIds(ids);
      res.json(parts);
    } catch (error) {
      console.error("Error fetching selected parts:", error);
      res.status(500).json({ message: "Failed to fetch selected parts" });
    }
  });

  // Get all builds
  app.get("/api/builds", async (req, res) => {
    try {
      const builds = await storage.getAllBuilds();
      res.json(builds);
    } catch (error) {
      console.error("Error fetching builds:", error);
      res.status(500).json({ message: "Failed to fetch builds" });
    }
  });

  // Get build by ID
  app.get("/api/builds/:id", async (req, res) => {
    try {
      const build = await storage.getBuildById(req.params.id);

      if (!build) {
        return res.status(404).json({ message: "Build not found" });
      }

      res.json(build);
    } catch (error) {
      console.error("Error fetching build:", error);
      res.status(500).json({ message: "Failed to fetch build" });
    }
  });

  // Create new build
  app.post("/api/builds", async (req, res) => {
    try {
      const validation = insertBuildSchema.safeParse(req.body);

      if (!validation.success) {
        return res.status(400).json({
          message: "Invalid build data",
          errors: validation.error.errors,
        });
      }

      const build = await storage.createBuild(validation.data);
      res.status(201).json(build);
    } catch (error) {
      console.error("Error creating build:", error);
      res.status(500).json({ message: "Failed to create build" });
    }
  });

  // Update build
  app.patch("/api/builds/:id", async (req, res) => {
    try {
      const build = await storage.updateBuild(req.params.id, req.body);

      if (!build) {
        return res.status(404).json({ message: "Build not found" });
      }

      res.json(build);
    } catch (error) {
      console.error("Error updating build:", error);
      res.status(500).json({ message: "Failed to update build" });
    }
  });

  // Delete build
  app.delete("/api/builds/:id", async (req, res) => {
    try {
      const success = await storage.deleteBuild(req.params.id);

      if (!success) {
        return res.status(404).json({ message: "Build not found" });
      }

      res.status(204).send();
    } catch (error) {
      console.error("Error deleting build:", error);
      res.status(500).json({ message: "Failed to delete build" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
