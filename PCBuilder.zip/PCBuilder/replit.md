# PCFind - PC Building Platform

## Overview

PCFind is a web application designed to help Filipino PC builders find compatible components, compare prices across multiple retailers, and build their dream PC with confidence. The platform aggregates parts from major Philippine retailers (Lazada, Shopee, PC Express, and EasyPC) and provides real-time compatibility checking to ensure all selected components work together.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework**: React with TypeScript
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack React Query for server state management
- **UI Components**: Radix UI primitives with shadcn/ui component library
- **Styling**: Tailwind CSS with custom dark mode theme using CSS variables
- **Form Handling**: React Hook Form with Zod validation

**Design System**: 
- Dark-themed UI with gaming-inspired aesthetics tailored for the Philippine market
- Custom color palette using HSL values for consistent theming
- Component variants managed through class-variance-authority
- Design guidelines specified in `design_guidelines.md` for exact mockup matching

### Backend Architecture

**Server Framework**: Express.js with TypeScript
- RESTful API architecture
- In-memory storage implementation (MemStorage class) for development
- Prepared for migration to persistent database storage
- Middleware for request logging and error handling

**API Endpoints**:
- `GET /api/parts` - Retrieve all parts or filter by category
- `GET /api/parts/:id` - Retrieve specific part details
- `POST /api/parts/selected` - Retrieve multiple parts by IDs for build summary
- `GET /api/builds` - Retrieve saved builds
- `GET /api/builds/:id` - Retrieve specific build
- `POST /api/builds` - Create new build
- `PUT /api/builds/:id` - Update existing build
- `DELETE /api/builds/:id` - Delete build

### Data Models

**Parts Schema**:
- Categories: CPU, GPU, Motherboard, RAM, Storage, PSU, Case, Cooling
- Compatibility metadata: socket, chipset, formFactor, ramType, wattage, TDP
- Retailer information: primary retailer and availability across platforms
- Flexible specs stored as JSONB for category-specific attributes

**Builds Schema**:
- Components object mapping category keys to part IDs
- Compatibility status tracking
- Total price calculation
- Creation timestamp

### Database Strategy

**Current**: Drizzle ORM configured for PostgreSQL with schema defined but using in-memory storage
**Migration Path**: Schema ready for Neon serverless PostgreSQL deployment
- Connection pooling via @neondatabase/serverless
- Schema migrations managed through drizzle-kit
- Environment-based database URL configuration

### Build & Development Tools

**Build Pipeline**:
- Vite for frontend bundling with React plugin
- esbuild for server-side bundling
- TypeScript compilation with path aliases
- Development server with HMR and error overlay

**Development Environment**:
- Replit-specific plugins for cartographer and dev banner
- Automatic Vite middleware integration in development
- Static file serving in production

### Compatibility System

**Validation Rules** (to be implemented):
- CPU socket must match motherboard socket
- RAM type (DDR4/DDR5) must match motherboard support
- PSU wattage must exceed total TDP plus 20% headroom
- Case form factor must accommodate motherboard form factor
- Chipset compatibility for CPU/motherboard pairing

### External Dependencies

**UI Component Libraries**:
- Radix UI for accessible, unstyled primitives
- shadcn/ui for pre-styled component implementations
- Lucide React for consistent iconography

**Data Fetching**:
- TanStack React Query for caching and synchronization
- Custom query client with automatic error handling

**Styling Tools**:
- Tailwind CSS for utility-first styling
- PostCSS with autoprefixer for browser compatibility
- class-variance-authority for component variant management

**Validation**:
- Zod for runtime type validation
- drizzle-zod for schema-based validation
- @hookform/resolvers for form validation integration

**Date Handling**:
- date-fns for date formatting and manipulation

**Philippine Retailer Integration** (planned):
- Lazada API/scraping
- Shopee API/scraping  
- PC Express data integration
- EasyPC data integration