# PCFind - Design Guidelines

## Design Approach
**User-Specified Design**: The UI must match the provided mockups exactly. This is a dark-themed, tech-focused PC building platform with a modern, gaming-inspired aesthetic tailored for the Philippine market.

## Core Design Elements

### A. Color Palette

**Dark Mode (Primary)**
- Background Primary: 10 14% 10% (deep navy #0a0e1a)
- Background Secondary: 220 24% 15% (dark slate #1a1f2e)
- Background Elevated: 220 20% 20% (card backgrounds)
- Primary Brand: 217 91% 60% (bright blue #3b82f6)
- Accent Cyan: 189 94% 43% (RGB aesthetic highlights)
- Text Primary: 0 0% 100% (white)
- Text Secondary: 220 15% 70% (muted gray)
- Success Green: 142 76% 36% (compatibility check)
- Warning Amber: 38 92% 50% (compatibility warnings)
- Border: 220 20% 25% (subtle dividers)

### B. Typography

**Font Stack**: System fonts (SF Pro, Segoe UI, sans-serif)

**Hierarchy**:
- Hero Title: text-5xl font-bold (48-60px)
- Section Headings: text-3xl font-bold (30-36px)
- Card Titles: text-xl font-semibold (20-24px)
- Body Text: text-base (16px)
- Small Text: text-sm (14px)
- Micro Text: text-xs (12px)

### C. Layout System

**Spacing Primitives**: Tailwind units of 2, 4, 6, 8, 12, 16, 20, 24
- Section Padding: py-16 to py-24
- Card Padding: p-4 to p-6
- Grid Gaps: gap-4 to gap-6
- Container: max-w-7xl mx-auto px-4

**Grid Systems**:
- Category Cards: grid-cols-2 md:grid-cols-3 lg:grid-cols-6
- Product Cards: grid-cols-1 md:grid-cols-2 lg:grid-cols-3
- Feature Steps: grid-cols-1 md:grid-cols-3

### D. Component Library

**Navigation Bar**
- Fixed top, dark background with subtle border-b
- Logo on left (blue/cyan gradient text or icon)
- Menu items: Home, Browse Parts, PC Builder, Saved Builds, Help, About
- Theme toggle on right (moon/sun icon)
- Height: h-16, px-4 spacing

**Hero Section**
- Full viewport height background with PC components image (motherboard, RGB fans, GPUs)
- Dark overlay (bg-black/50) for text readability
- Centered content: large heading, subtitle, search bar
- Prominent CTA buttons: "Start Building" (primary blue), "Browse Parts" (outline white)
- Search bar: rounded-lg, dark bg with blue border on focus

**Category Cards**
- Rounded-xl with dark background
- Icon at top (CPU, GPU, RAM, Storage, Cooling, Case icons from Heroicons)
- Category name in bold
- Hover: scale-105 transform, blue border glow
- Blue accent gradient on hover

**Product Cards**
- Image at top with retailer badges overlay (Lazada/Shopee/PC Express/EasyPC)
- Product name, specs (bullet points), price
- "Add to Build" button (primary blue)
- Hover: lift effect with shadow-xl
- Badges: small pills with store logos/colors

**PC Builder Interface**
- Left sidebar: component categories with icons
- Center: visual build preview with empty slots
- Right panel: Build Summary with total price, compatibility status
- Component slots: dashed borders when empty, filled with selected part
- Compatibility Check section: green checkmarks or red warnings with icons

**Part Selection Cards**
- Checkbox or radio for selection
- Part image thumbnail
- Name, key specs, price
- "Add to Build" action button
- Selected state: blue border, checkmark overlay

**Build Summary Panel**
- Sticky positioning
- List of selected components with mini previews
- Running total price in PHP (₱)
- Compatibility status indicator (green/red with icon)
- "Save Build" and "Clear Build" buttons

**Help/Tutorial Components**
- Motherboard diagram with labeled callouts (Socket, RAM slots, PCIe, etc.)
- FAQ accordion with chevron icons
- Quick Tips cards with warning/info icons
- Step-by-step numbered guides

**Footer**
- Dark background with subtle top border
- Multi-column layout: About, Quick Links, Contact, Partner Stores
- Store partner logos in grayscale, color on hover
- Social media icons
- Copyright text

### E. Interactive Elements

**Buttons**
- Primary: bg-blue-600 hover:bg-blue-700, rounded-lg, px-6 py-3
- Outline: border-2 border-white/50, backdrop-blur when over images
- Icon buttons: rounded-full, p-2, hover:bg-white/10
- Disabled: opacity-50, cursor-not-allowed

**Filters & Search**
- Filter chips: rounded-full pills, blue when active
- Search input: dark bg, blue focus ring, search icon left
- Grid/List toggle: icon buttons, active state highlighted

**Animations**
- Card hover: transform scale-105, transition-all duration-200
- Button hover: brightness increase, no custom animations
- Page transitions: fade-in on load
- Minimal use of animations to maintain performance

## Images

**Hero Image**: Full-width background showing high-end PC components - RGB-lit motherboard, GPUs, cooling fans, cables. Dark overlay to ensure white text readability. Futuristic, gaming aesthetic.

**Product Images**: Component photos on white/transparent backgrounds for product cards.

**Tutorial Diagrams**: Technical illustrations showing motherboard layouts, component compatibility, cable management.

## Key Design Patterns

- **Retailer Integration**: Display Lazada/Shopee/PC Express/EasyPC badges on products
- **PHP Pricing**: All prices in Philippine Peso (₱) format
- **Compatibility Focus**: Visual indicators (green checks, red warnings) for part compatibility
- **Mobile-First**: Stack grids to single column, collapsible menus
- **Dark Theme Consistency**: Maintain dark backgrounds across all pages, forms, inputs
- **Icon System**: Use Heroicons for all UI icons (outline style)
- **Tech Aesthetic**: Subtle RGB accents, circuit board patterns, gaming-inspired touches