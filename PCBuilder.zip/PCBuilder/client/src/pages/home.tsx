import { Link, useLocation } from "wouter";
import { Search, Cpu, Monitor, HardDrive, Database, Fan, Box, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import heroImage from "@assets/generated_images/PC_gaming_components_hero_background_eefc2a77.png";

const categories = [
  { name: "CPU", icon: Cpu, label: "Processor" },
  { name: "GPU", icon: Monitor, label: "Graphics Cards" },
  { name: "RAM", icon: Database, label: "Memory" },
  { name: "Storage", icon: HardDrive, label: "SSD & HDD" },
  { name: "Cooling", icon: Fan, label: "Fans & AIO" },
  { name: "Case", icon: Box, label: "PC Cases" },
];

const steps = [
  {
    number: "1",
    title: "Search & Browse",
    description: "Find PC parts with real Philippine retailers (Lazada, Shopee, PC Express, and EasyPC)",
  },
  {
    number: "2",
    title: "Check Compatibility",
    description: "Our tool ensures your parts work together perfectly",
  },
  {
    number: "3",
    title: "Save & Build",
    description: "Save your build and purchase from your preferred store",
  },
];

export default function Home() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section
        className="relative h-screen flex items-center justify-center"
        style={{
          backgroundImage: `url(${heroImage})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      >
        <div className="absolute inset-0 bg-black/60" />
        <div className="relative z-10 max-w-4xl mx-auto px-4 text-center">
          <h1 className="text-5xl md:text-6xl font-bold mb-6 text-white">
            Find Your Perfect PC Parts
          </h1>
          <p className="text-xl md:text-2xl mb-8 text-gray-200">
            Your one-stop shop for PC building in the Philippines. Check compatibility, compare prices, and build with confidence.
          </p>

          <div className="max-w-2xl mx-auto mb-8">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-muted-foreground w-5 h-5" />
              <Input
                type="search"
                placeholder="Ask me anything about PC building or search for parts..."
                className="pl-12 h-14 text-lg bg-background/80 backdrop-blur border-primary/50 focus:border-primary"
                data-testid="input-hero-search"
              />
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              size="lg"
              className="text-lg px-8 h-12 w-full sm:w-auto"
              onClick={() => setLocation("/pc-builder")}
              data-testid="button-start-building"
            >
              Start Building
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="text-lg px-8 h-12 w-full sm:w-auto bg-background/20 backdrop-blur border-white/50 text-white hover:bg-background/40"
              onClick={() => setLocation("/browse-parts")}
              data-testid="button-browse-parts"
            >
              Browse Parts
            </Button>
          </div>
        </div>
      </section>

      {/* Browse by Category */}
      <section className="py-20 bg-background">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Browse by Category</h2>
            <p className="text-lg text-muted-foreground">
              Find the components you need for your perfect build
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {categories.map((category) => (
              <Link key={category.name} href={`/browse-parts?category=${category.name}`}>
                <Card className="p-6 text-center hover-elevate cursor-pointer transition-all duration-200 hover:scale-105 hover:border-primary/50">
                  <div className="flex justify-center mb-3">
                    <div className="p-3 bg-primary/10 rounded-lg">
                      <category.icon className="w-8 h-8 text-primary" />
                    </div>
                  </div>
                  <h3 className="font-semibold text-sm mb-1">{category.name}</h3>
                  <p className="text-xs text-muted-foreground">{category.label}</p>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 bg-card">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">How It Works</h2>
            <p className="text-lg text-muted-foreground">
              Building your PC is easy with PCFind
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {steps.map((step) => (
              <div key={step.number} className="text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary text-primary-foreground text-2xl font-bold mb-4">
                  {step.number}
                </div>
                <h3 className="text-xl font-semibold mb-3">{step.title}</h3>
                <p className="text-muted-foreground">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Ready to Build CTA */}
      <section className="py-20 bg-background">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to Build Your PC?</h2>
          <p className="text-lg text-muted-foreground mb-8">
            Start by browsing parts or jump straight to our PC builder
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              size="lg"
              className="px-8 w-full sm:w-auto"
              onClick={() => setLocation("/browse-parts")}
              data-testid="button-cta-browse"
            >
              Browse Parts
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="px-8 w-full sm:w-auto"
              onClick={() => setLocation("/pc-builder")}
              data-testid="button-cta-build"
            >
              Start Building
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}
