import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Plus, AlertCircle, CheckCircle2, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import type { Part, BuildComponents } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";

const componentCategories = [
  { key: "cpu", label: "CPU", required: true },
  { key: "gpu", label: "GPU", required: false },
  { key: "motherboard", label: "Motherboard", required: true },
  { key: "ram", label: "RAM", required: true },
  { key: "storage", label: "Storage", required: true },
  { key: "psu", label: "PSU", required: true },
  { key: "case", label: "Case", required: true },
  { key: "cooling", label: "Cooling", required: false },
];

export default function PCBuilder() {
  const [selectedCategory, setSelectedCategory] = useState<string>("cpu");
  const [buildComponents, setBuildComponents] = useState<BuildComponents>({});
  const [searchQuery, setSearchQuery] = useState("");
  const { toast } = useToast();

  const { data: parts } = useQuery<Part[]>({
    queryKey: ["/api/parts", selectedCategory],
  });

  const { data: selectedParts } = useQuery<Part[]>({
    queryKey: ["/api/parts/selected", Object.values(buildComponents)],
    enabled: Object.keys(buildComponents).length > 0,
  });

  const saveBuildMutation = useMutation({
    mutationFn: async (buildName: string) => {
      const totalPrice = selectedParts?.reduce((sum, part) => sum + part.price, 0) || 0;
      return apiRequest("POST", "/api/builds", {
        name: buildName,
        components: buildComponents,
        totalPrice,
        compatible: { compatible: true, issues: [] },
      });
    },
    onSuccess: () => {
      toast({
        title: "Build saved!",
        description: "Your PC build has been saved successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/builds"] });
    },
  });

  const addComponent = (partId: string) => {
    setBuildComponents({
      ...buildComponents,
      [selectedCategory]: partId,
    });
    toast({
      title: "Component added",
      description: "Part added to your build",
    });
  };

  const removeComponent = (category: string) => {
    const newComponents = { ...buildComponents };
    delete newComponents[category as keyof BuildComponents];
    setBuildComponents(newComponents);
  };

  const clearBuild = () => {
    setBuildComponents({});
    toast({
      title: "Build cleared",
      description: "All components have been removed",
    });
  };

  const filteredParts = parts?.filter((part) =>
    part.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const totalPrice = selectedParts?.reduce((sum, part) => sum + part.price, 0) || 0;
  const requiredComponents = componentCategories.filter((c) => c.required);
  const selectedRequiredCount = requiredComponents.filter(
    (c) => buildComponents[c.key as keyof BuildComponents]
  ).length;

  return (
    <div className="min-h-screen pt-20 pb-12">
      <div className="max-w-7xl mx-auto px-4">
        <h1 className="text-4xl font-bold mb-8">PC Builder</h1>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Component Selection */}
          <div className="lg:col-span-2 space-y-6">
            {/* Search */}
            <div>
              <Input
                type="search"
                placeholder="Search for parts to add..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                data-testid="input-search-builder"
              />
            </div>

            {/* Category Tabs */}
            <div className="flex gap-2 overflow-x-auto pb-2">
              {componentCategories.map((category) => (
                <Button
                  key={category.key}
                  variant={selectedCategory === category.key ? "default" : "outline"}
                  onClick={() => setSelectedCategory(category.key)}
                  className="whitespace-nowrap"
                  data-testid={`button-category-${category.key}`}
                >
                  {category.label}
                  {buildComponents[category.key as keyof BuildComponents] && (
                    <CheckCircle2 className="w-4 h-4 ml-2" />
                  )}
                </Button>
              ))}
            </div>

            {/* Available Parts */}
            <div className="space-y-4">
              {filteredParts?.map((part) => (
                <Card
                  key={part.id}
                  className="p-4 hover-elevate"
                  data-testid={`card-builder-part-${part.id}`}
                >
                  <div className="flex items-start gap-4">
                    <div className="bg-muted w-24 h-24 rounded-lg flex items-center justify-center text-xs text-muted-foreground">
                      {part.category}
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold mb-1">{part.name}</h3>
                      <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-sm text-muted-foreground mb-2">
                        {Object.entries(part.specs as Record<string, string>)
                          .slice(0, 4)
                          .map(([key, value]) => (
                            <div key={key}>
                              <span className="font-medium">{key}:</span> {value}
                            </div>
                          ))}
                      </div>
                      <div className="flex items-center gap-2 mt-2">
                        <p className="text-xl font-bold text-primary">
                          ₱{part.price.toLocaleString()}
                        </p>
                        <Badge variant="outline">{part.retailer}</Badge>
                      </div>
                    </div>
                    <Button
                      onClick={() => addComponent(part.id)}
                      disabled={buildComponents[selectedCategory as keyof BuildComponents] === part.id}
                      data-testid={`button-add-part-${part.id}`}
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      Add to Build
                    </Button>
                  </div>
                </Card>
              ))}

              {(!filteredParts || filteredParts.length === 0) && (
                <Card className="p-12 text-center">
                  <p className="text-muted-foreground">No parts available in this category</p>
                </Card>
              )}
            </div>
          </div>

          {/* Build Summary */}
          <div className="lg:sticky lg:top-24 h-fit">
            <Card className="p-6">
              <h2 className="text-xl font-bold mb-4">Build Summary</h2>

              {Object.keys(buildComponents).length === 0 ? (
                <div className="text-center py-8">
                  <p className="text-muted-foreground">No parts added yet</p>
                  <p className="text-sm text-muted-foreground mt-2">
                    Start building your PC!
                  </p>
                </div>
              ) : (
                <>
                  <div className="space-y-3 mb-6">
                    {componentCategories.map((category) => {
                      const partId = buildComponents[category.key as keyof BuildComponents];
                      const part = selectedParts?.find((p) => p.id === partId);

                      if (!part) {
                        return (
                          <div
                            key={category.key}
                            className="p-3 border-2 border-dashed border-border rounded-lg"
                          >
                            <p className="text-sm text-muted-foreground">
                              {category.label}
                              {category.required && (
                                <span className="text-destructive ml-1">*</span>
                              )}
                            </p>
                          </div>
                        );
                      }

                      return (
                        <div
                          key={category.key}
                          className="p-3 bg-card border border-primary/20 rounded-lg"
                          data-testid={`summary-${category.key}`}
                        >
                          <div className="flex items-start justify-between gap-2">
                            <div className="flex-1 min-w-0">
                              <p className="text-xs text-muted-foreground mb-1">
                                {category.label}
                              </p>
                              <p className="font-medium text-sm truncate">{part.name}</p>
                              <p className="text-sm text-primary font-semibold">
                                ₱{part.price.toLocaleString()}
                              </p>
                            </div>
                            <Button
                              size="icon"
                              variant="ghost"
                              onClick={() => removeComponent(category.key)}
                              data-testid={`button-remove-${category.key}`}
                            >
                              <X className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  <div className="border-t border-border pt-4 mb-6">
                    <div className="flex justify-between items-center mb-2">
                      <span className="font-semibold">Total Price:</span>
                      <span className="text-2xl font-bold text-primary" data-testid="text-total-price">
                        ₱{totalPrice.toLocaleString()}
                      </span>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {selectedRequiredCount} of {requiredComponents.length} required components
                    </p>
                  </div>

                  <div className="space-y-2">
                    <Button
                      className="w-full"
                      onClick={() => saveBuildMutation.mutate("My PC Build")}
                      disabled={selectedRequiredCount < requiredComponents.length}
                      data-testid="button-save-build"
                    >
                      Save Build
                    </Button>
                    <Button
                      variant="outline"
                      className="w-full"
                      onClick={clearBuild}
                      data-testid="button-clear-build"
                    >
                      Clear Build
                    </Button>
                  </div>
                </>
              )}
            </Card>

            {/* Compatibility Check */}
            <Card className="p-6 mt-4">
              <h3 className="font-semibold mb-3 flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-chart-3" />
                Compatibility Check
              </h3>
              {Object.keys(buildComponents).length === 0 ? (
                <p className="text-sm text-muted-foreground">
                  Add parts to check compatibility
                </p>
              ) : (
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm text-chart-3">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>All components compatible</span>
                  </div>
                </div>
              )}
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
