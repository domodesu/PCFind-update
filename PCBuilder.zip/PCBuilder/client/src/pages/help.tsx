import { useState } from "react";
import { ChevronDown, ChevronUp, Info, AlertTriangle } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const faqs = [
  {
    question: "How does the compatibility checker work?",
    answer:
      "Our PC Builder automatically validates your component selections in real-time. It verifies that your CPU socket matches the motherboard, RAM type is supported (DDR4/DDR5), power supply has sufficient wattage, and all physical dimensions fit your chosen case. You'll receive real-time warnings if any incompatibilities are detected.",
  },
  {
    question: "How accurate are the prices?",
    answer:
      "Prices are sourced from major Philippine retailers including Lazada, Shopee, PC Express, and EasyPC. We update our database regularly to ensure pricing accuracy. However, actual prices may vary slightly due to promotions or stock availability.",
  },
  {
    question: "Can I save multiple PC builds?",
    answer:
      "Yes! You can save as many PC builds as you want. Each saved build includes all your selected components, total cost, and compatibility check results. You can access them from the 'Saved Builds' page to view, edit, or share them.",
  },
  {
    question: "Can I purchase parts directly through PCFind?",
    answer:
      "Currently, PCFind serves as a comparison and compatibility tool. When you find the parts you want, we provide direct links to the retailer where you can make your purchase. This ensures you get the best deals from trusted Philippine stores.",
  },
  {
    question: "I'm a complete beginner. Where should I start?",
    answer:
      "Start by determining your budget and use case (gaming, work, content creation). Then use our PC Builder tool which guides you through selecting compatible components step-by-step. Our compatibility checker will help ensure you make the right choices. For more guidance, check out our Quick Tips section below.",
  },
  {
    question: "How do I know if my PSU has enough power?",
    answer:
      "Our PC Builder automatically calculates your system's total power consumption based on the selected components. We recommend a PSU with at least 20% headroom calculated usage. For example, if your build uses 500W, choose a 650W PSU for safety and future upgrades.",
  },
];

const quickTips = [
  {
    title: "CPU & Motherboard",
    description:
      "Always check that your CPU socket type (AM5, LGA1700, etc.) matches your motherboard. This is the most critical compatibility requirement.",
    icon: "cpu",
  },
  {
    title: "RAM Compatibility",
    description:
      "Modern builds use either DDR4 or DDR5 RAM. Your motherboard will only support one type, so choose accordingly. Check the maximum supported speed as well.",
    icon: "memory",
  },
  {
    title: "GPU Clearance",
    description:
      "High-end graphics cards can be quite large. Make sure your case has enough clearance and your PSU has the required PCIe power connectors.",
    icon: "gpu",
  },
  {
    title: "Storage Options",
    description:
      "NVMe M.2 SSDs are the fastest option for modern builds. Check your motherboard for M.2 slots and ensure compatibility with PCIe 3.0 or 4.0.",
    icon: "storage",
  },
];

export default function Help() {
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(null);

  return (
    <div className="min-h-screen pt-20 pb-12">
      <div className="max-w-5xl mx-auto px-4">
        <h1 className="text-4xl font-bold mb-4">Help & Tutorials</h1>
        <p className="text-lg text-muted-foreground mb-12">
          Learn how to use PCFind and build your perfect PC
        </p>

        {/* Compatibility Diagram */}
        <Card className="p-8 mb-12 bg-card">
          <h2 className="text-2xl font-bold mb-6">
            Understanding PC Component Compatibility
          </h2>
          <div className="bg-muted/30 rounded-lg p-8 mb-6">
            <div className="aspect-video flex items-center justify-center text-muted-foreground border-2 border-dashed border-border rounded-lg">
              <div className="text-center">
                <p className="text-sm mb-2">Motherboard Diagram</p>
                <p className="text-xs">
                  CPU Socket • RAM Slots • PCIe Slots • SATA • M.2 Slot • Storage
                </p>
              </div>
            </div>
          </div>
          <p className="text-muted-foreground">
            This diagram shows the key compatibility points between PC components. Make sure
            your CPU socket matches your motherboard, RAM type is supported, and your PSU has
            enough power for all components.
          </p>
        </Card>

        {/* FAQ Section */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-6">Frequently Asked Questions</h2>
          <div className="space-y-3">
            {faqs.map((faq, index) => (
              <Card key={index} className="overflow-hidden">
                <Button
                  variant="ghost"
                  className="w-full justify-between p-6 h-auto text-left hover-elevate"
                  onClick={() => setOpenFaqIndex(openFaqIndex === index ? null : index)}
                  data-testid={`button-faq-${index}`}
                >
                  <span className="font-semibold pr-4">{faq.question}</span>
                  {openFaqIndex === index ? (
                    <ChevronUp className="w-5 h-5 flex-shrink-0" />
                  ) : (
                    <ChevronDown className="w-5 h-5 flex-shrink-0" />
                  )}
                </Button>
                {openFaqIndex === index && (
                  <div className="px-6 pb-6">
                    <p className="text-muted-foreground">{faq.answer}</p>
                  </div>
                )}
              </Card>
            ))}
          </div>
        </section>

        {/* Quick Tips */}
        <section>
          <h2 className="text-2xl font-bold mb-6">Quick Tips</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {quickTips.map((tip, index) => (
              <Card key={index} className="p-6" data-testid={`card-tip-${index}`}>
                <div className="flex items-start gap-4">
                  <div className="p-3 bg-primary/10 rounded-lg">
                    <Info className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold mb-2">{tip.title}</h3>
                    <p className="text-sm text-muted-foreground">{tip.description}</p>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}
