import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Search, Grid3x3, List, SlidersHorizontal } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import type { Part } from "@shared/schema";

export default function BrowseParts() {
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [sortBy, setSortBy] = useState("popular");

  const { data: parts, isLoading } = useQuery<Part[]>({
    queryKey: ["/api/parts", selectedCategory, sortBy],
  });

  const filteredParts = parts?.filter((part) =>
    part.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const retailerColors: Record<string, string> = {
    Lazada: "bg-orange-500",
    Shopee: "bg-orange-600",
    "PC Express": "bg-blue-500",
    EasyPC: "bg-green-500",
  };

  return (
    <div className="min-h-screen pt-20 pb-12">
      <div className="max-w-7xl mx-auto px-4">
        <h1 className="text-4xl font-bold mb-8">Browse PC Parts</h1>

        {/* Search and Filters */}
        <div className="mb-8 space-y-4">
          <div className="flex flex-col lg:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-5 h-5" />
              <Input
                type="search"
                placeholder="Search parts..."
                className="pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                data-testid="input-search-parts"
              />
            </div>

            <div className="flex gap-2">
              <Button
                variant="outline"
                size="icon"
                data-testid="button-filters"
              >
                <SlidersHorizontal className="w-5 h-5" />
              </Button>

              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-[180px]" data-testid="select-sort">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="popular">Most Popular</SelectItem>
                  <SelectItem value="price-low">Price: Low to High</SelectItem>
                  <SelectItem value="price-high">Price: High to Low</SelectItem>
                  <SelectItem value="newest">Newest</SelectItem>
                </SelectContent>
              </Select>

              <div className="flex gap-1 border border-border rounded-md p-1">
                <Button
                  size="icon"
                  variant={viewMode === "grid" ? "secondary" : "ghost"}
                  onClick={() => setViewMode("grid")}
                  data-testid="button-view-grid"
                >
                  <Grid3x3 className="w-5 h-5" />
                </Button>
                <Button
                  size="icon"
                  variant={viewMode === "list" ? "secondary" : "ghost"}
                  onClick={() => setViewMode("list")}
                  data-testid="button-view-list"
                >
                  <List className="w-5 h-5" />
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Parts Grid/List */}
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <Card key={i} className="p-6 animate-pulse">
                <div className="bg-muted h-48 rounded-lg mb-4" />
                <div className="bg-muted h-6 rounded mb-2" />
                <div className="bg-muted h-4 rounded w-3/4" />
              </Card>
            ))}
          </div>
        ) : (
          <div
            className={
              viewMode === "grid"
                ? "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
                : "space-y-4"
            }
          >
            {filteredParts?.map((part) => (
              <Card
                key={part.id}
                className="overflow-hidden hover-elevate transition-all duration-200 hover:scale-[1.02]"
                data-testid={`card-part-${part.id}`}
              >
                <div className="relative">
                  <div className="bg-muted aspect-video flex items-center justify-center text-muted-foreground">
                    {part.category}
                  </div>
                  <div className="absolute top-2 right-2">
                    <Badge className={retailerColors[part.retailer]}>
                      {part.retailer}
                    </Badge>
                  </div>
                </div>

                <div className="p-6">
                  <Badge variant="outline" className="mb-2">
                    {part.category}
                  </Badge>
                  <h3 className="font-semibold text-lg mb-2">{part.name}</h3>

                  <div className="space-y-1 mb-4 text-sm text-muted-foreground">
                    {Object.entries(part.specs as Record<string, string>)
                      .slice(0, 3)
                      .map(([key, value]) => (
                        <div key={key} className="flex justify-between">
                          <span>{key}</span>
                          <span className="font-medium text-foreground">
                            {value}
                          </span>
                        </div>
                      ))}
                  </div>

                  <div className="flex items-center justify-between mt-4 pt-4 border-t border-border">
                    <div>
                      <p className="text-2xl font-bold text-primary">
                        ₱{part.price.toLocaleString()}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {part.retailer}
                      </p>
                    </div>
                    <Button data-testid={`button-add-${part.id}`}>
                      Add to Build
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}

        {!isLoading && (!filteredParts || filteredParts.length === 0) && (
          <div className="text-center py-12">
            <p className="text-xl text-muted-foreground">No parts found</p>
            <p className="text-sm text-muted-foreground mt-2">
              Try adjusting your search or filters
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
