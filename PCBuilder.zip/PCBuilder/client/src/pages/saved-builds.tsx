import { useQuery } from "@tanstack/react-query";
import { Plus, Calendar } from "lucide-react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import type { Build } from "@shared/schema";

export default function SavedBuilds() {
  const [, setLocation] = useLocation();
  const { data: builds, isLoading } = useQuery<Build[]>({
    queryKey: ["/api/builds"],
  });

  return (
    <div className="min-h-screen pt-20 pb-12">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-4xl font-bold">My Saved Builds</h1>
          <Button onClick={() => setLocation("/pc-builder")} data-testid="button-new-build">
            <Plus className="w-4 h-4 mr-2" />
            New Build
          </Button>
        </div>

        <p className="text-muted-foreground mb-8">
          View and manage your PC build configurations
        </p>

        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(3)].map((_, i) => (
              <Card key={i} className="p-6 animate-pulse">
                <div className="bg-muted h-6 rounded mb-4" />
                <div className="bg-muted h-4 rounded w-3/4 mb-2" />
                <div className="bg-muted h-4 rounded w-1/2" />
              </Card>
            ))}
          </div>
        ) : !builds || builds.length === 0 ? (
          <div className="max-w-md mx-auto text-center py-16">
            <div className="mb-6">
              <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-muted mb-4">
                <Plus className="w-10 h-10 text-muted-foreground" />
              </div>
              <h2 className="text-2xl font-bold mb-2">You haven't saved any builds yet</h2>
              <p className="text-muted-foreground mb-6">
                Start building your dream PC today!
              </p>
              <Button
                size="lg"
                onClick={() => setLocation("/pc-builder")}
                data-testid="button-create-first-build"
              >
                <Plus className="w-4 h-4 mr-2" />
                Create Your First Build
              </Button>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {builds.map((build) => (
              <Card
                key={build.id}
                className="p-6 hover-elevate transition-all duration-200 hover:scale-[1.02] cursor-pointer"
                data-testid={`card-build-${build.id}`}
              >
                <div className="mb-4">
                  <h3 className="text-xl font-semibold mb-2">{build.name}</h3>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Calendar className="w-4 h-4" />
                    <span>{new Date(build.createdAt).toLocaleDateString()}</span>
                  </div>
                </div>

                <div className="space-y-2 mb-4">
                  {Object.entries(build.components as Record<string, string>).map(
                    ([category, partId]) => (
                      <div key={category} className="flex justify-between text-sm">
                        <span className="text-muted-foreground capitalize">
                          {category}:
                        </span>
                        <Badge variant="outline">Selected</Badge>
                      </div>
                    )
                  )}
                </div>

                <div className="pt-4 border-t border-border">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Total:</span>
                    <span className="text-2xl font-bold text-primary">
                      ₱{build.totalPrice.toLocaleString()}
                    </span>
                  </div>
                </div>

                <div className="flex gap-2 mt-4">
                  <Button className="flex-1" variant="outline">View</Button>
                  <Button className="flex-1">Edit</Button>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
