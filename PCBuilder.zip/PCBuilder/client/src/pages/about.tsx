import { CheckCircle2, Users, MapPin, Zap } from "lucide-react";
import { Card } from "@/components/ui/card";

const features = [
  {
    icon: MapPin,
    title: "Centralized Platform",
    description:
      "Browse parts from multiple Philippine retailers in one place - no more tab hopping between Lazada, Shopee, PC Express, and EasyPC.",
  },
  {
    icon: CheckCircle2,
    title: "Real-Time Compatibility",
    description:
      "Instant compatibility checks ensure all your parts work together perfectly before you buy.",
  },
  {
    icon: Users,
    title: "Beginner-Friendly",
    description:
      "Clean, intuitive interface designed for both beginners and experienced builders.",
  },
  {
    icon: Zap,
    title: "Philippine-Focused",
    description:
      "Pricing and availability tailored specifically for the Philippine market with accurate local pricing.",
  },
];

const partners = [
  { name: "Lazada", color: "text-orange-500" },
  { name: "Shopee", color: "text-orange-600" },
  { name: "PC Express", color: "text-blue-500" },
  { name: "EasyPC", color: "text-green-500" },
];

export default function About() {
  return (
    <div className="min-h-screen pt-20 pb-12">
      <div className="max-w-5xl mx-auto px-4">
        <h1 className="text-4xl font-bold mb-4">About PCFind</h1>
        <p className="text-xl text-muted-foreground mb-12">
          Your trusted guide to PC building in the Philippines
        </p>

        {/* Introduction */}
        <section className="mb-12">
          <Card className="p-8">
            <p className="text-lg text-foreground/90 mb-4">
              In today's digital age, building a personal computer (PC) has become essential for
              gamers, students, professionals, and creative individuals. Custom-built PCs offer
              better performance, value, and flexibility compared to pre-built systems. However,
              choosing compatible parts and finding affordable deals remains challenging.
            </p>
          </Card>
        </section>

        {/* The Problem We Solve */}
        <section className="mb-12">
          <h2 className="text-3xl font-bold mb-6">The Problem We Solve</h2>
          <Card className="p-8">
            <p className="text-foreground/90 mb-4">
              For beginners, PC building can be overwhelming. You need to consider technical
              details like power supply compatibility, RAM specifications, processor support, and
              more. Even experienced builders face the hassle of manually checking specs and
              comparing prices across various platforms.
            </p>
            <p className="text-foreground/90">
              Popular online marketplaces like Lazada and Shopee allow purchasing PC components,
              but they lack two critical features:{" "}
              <strong>compatibility checking</strong> and{" "}
              <strong>specialized PC building guidance</strong>. This leaves users vulnerable to
              costly mistakes or relying solely on third-party advice from unclear sources.
            </p>
          </Card>
        </section>

        {/* Our Solution */}
        <section className="mb-12">
          <h2 className="text-3xl font-bold mb-6">Our Solution</h2>
          <Card className="p-8">
            <p className="text-foreground/90">
              PCFind addresses this gap by serving as both an online hub for PC parts and a
              virtual PC builder. We consolidate stocks and deals from local shops like PC Express
              and EasyPC, while helping users analyze their builds for compatibility and
              budget-friendliness.
            </p>
          </Card>
        </section>

        {/* What Makes PCFind Different */}
        <section className="mb-12">
          <h2 className="text-3xl font-bold mb-6">What Makes PCFind Different</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {features.map((feature, index) => (
              <Card key={index} className="p-6">
                <div className="flex items-start gap-4">
                  <div className="p-3 bg-primary/10 rounded-lg">
                    <feature.icon className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg mb-2">{feature.title}</h3>
                    <p className="text-muted-foreground">{feature.description}</p>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </section>

        {/* Our Mission */}
        <section className="mb-12">
          <h2 className="text-3xl font-bold mb-6">Our Mission</h2>
          <Card className="p-8 bg-primary/5 border-primary/20">
            <p className="text-lg text-foreground/90 text-center">
              To make PC building accessible, affordable, and stress-free for everyone in the
              Philippines. We believe that building your own PC should be an exciting journey, not
              a frustrating challenge.
            </p>
          </Card>
        </section>

        {/* Partner Stores */}
        <section>
          <h2 className="text-3xl font-bold mb-6">Partner Stores</h2>
          <Card className="p-8">
            <p className="text-foreground/90 mb-6">
              We work with trusted Philippine retailers to bring you the best selection and
              prices:
            </p>
            <div className="flex flex-wrap gap-6 justify-center">
              {partners.map((partner) => (
                <div
                  key={partner.name}
                  className="flex items-center justify-center px-6 py-3 bg-card border border-border rounded-lg hover-elevate cursor-pointer transition-all"
                >
                  <span className={`text-2xl font-bold ${partner.color}`}>
                    {partner.name}
                  </span>
                </div>
              ))}
            </div>
          </Card>
        </section>
      </div>
    </div>
  );
}
