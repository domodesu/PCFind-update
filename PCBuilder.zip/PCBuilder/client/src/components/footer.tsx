import { Link } from "wouter";

export function Footer() {
  const currentYear = new Date().getFullYear();

  const partnerStores = [
    { name: "Lazada", color: "text-orange-500" },
    { name: "Shopee", color: "text-orange-600" },
    { name: "PC Express", color: "text-blue-500" },
    { name: "EasyPC", color: "text-green-500" },
  ];

  return (
    <footer className="bg-card border-t border-border mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-lg font-semibold mb-4">About</h3>
            <p className="text-sm text-muted-foreground">
              Your trusted guide to PC building in the Philippines. Compare prices, check compatibility, and build with confidence.
            </p>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/browse-parts" className="text-muted-foreground hover:text-foreground transition-colors" data-testid="footer-link-browse">
                  Browse Parts
                </Link>
              </li>
              <li>
                <Link href="/pc-builder" className="text-muted-foreground hover:text-foreground transition-colors" data-testid="footer-link-builder">
                  PC Builder
                </Link>
              </li>
              <li>
                <Link href="/help" className="text-muted-foreground hover:text-foreground transition-colors" data-testid="footer-link-help">
                  Help & Tutorials
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Contact</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>support@pcfind.ph</li>
              <li>Manila, Philippines</li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Partner Stores</h3>
            <div className="flex flex-wrap gap-3">
              {partnerStores.map((store) => (
                <span
                  key={store.name}
                  className={`text-sm font-medium ${store.color} opacity-70 hover:opacity-100 transition-opacity cursor-pointer`}
                >
                  {store.name}
                </span>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-8 pt-8 border-t border-border text-center text-sm text-muted-foreground">
          <p>&copy; {currentYear} PCFind. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
