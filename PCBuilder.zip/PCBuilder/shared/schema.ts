import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// PC Part Categories
export type PartCategory = 'CPU' | 'GPU' | 'Motherboard' | 'RAM' | 'Storage' | 'PSU' | 'Case' | 'Cooling';

export type Retailer = 'Lazada' | 'Shopee' | 'PC Express' | 'EasyPC';

// PC Parts table
export const parts = pgTable("parts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  category: text("category").notNull(), // PartCategory
  price: integer("price").notNull(), // Price in PHP
  imageUrl: text("image_url"),
  specs: jsonb("specs").notNull(), // Key-value specs
  retailer: text("retailer").notNull(), // Primary retailer
  available: jsonb("available").notNull(), // Array of available retailers
  socket: text("socket"), // For CPU/Motherboard compatibility
  chipset: text("chipset"), // For Motherboard
  formFactor: text("form_factor"), // For Motherboard/Case/PSU
  ramType: text("ram_type"), // DDR4/DDR5 for RAM/Motherboard
  wattage: integer("wattage"), // For PSU
  tdp: integer("tdp"), // For CPU/GPU power requirements
});

export const insertPartSchema = createInsertSchema(parts).omit({
  id: true,
});

export type InsertPart = z.infer<typeof insertPartSchema>;
export type Part = typeof parts.$inferSelect;

// PC Builds table
export const builds = pgTable("builds", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  components: jsonb("components").notNull(), // Object with category keys and part IDs
  totalPrice: integer("total_price").notNull(),
  compatible: jsonb("compatible"), // Compatibility status object
  createdAt: text("created_at").notNull(),
});

export const insertBuildSchema = createInsertSchema(builds).omit({
  id: true,
  createdAt: true,
});

export type InsertBuild = z.infer<typeof insertBuildSchema>;
export type Build = typeof builds.$inferSelect;

// Build component structure
export interface BuildComponents {
  cpu?: string;
  gpu?: string;
  motherboard?: string;
  ram?: string;
  storage?: string;
  psu?: string;
  case?: string;
  cooling?: string;
}

// Compatibility check result
export interface CompatibilityCheck {
  compatible: boolean;
  issues: Array<{
    type: 'error' | 'warning';
    message: string;
  }>;
}

// FAQ item
export interface FAQItem {
  question: string;
  answer: string;
}

// Quick Tip
export interface QuickTip {
  title: string;
  description: string;
  icon: string;
}
