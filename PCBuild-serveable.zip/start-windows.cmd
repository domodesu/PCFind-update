@echo off
setlocal

REM Start lightweight static server for the built site on Windows
set NODE_CMD=node
where %NODE_CMD% >nul 2>nul
if errorlevel 1 (
  set NODE_CMD="C:\Program Files\nodejs\node.exe"
)

echo Starting PCFind static server on http://localhost:5173 ...
%NODE_CMD% "%~dp0quick-server.cjs"
pause


