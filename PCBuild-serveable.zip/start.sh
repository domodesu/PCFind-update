#!/usr/bin/env sh
DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
echo "Starting PCFind static server on http://localhost:5173 ..."
node "$DIR/quick-server.cjs"

